# Add-on Development

Full instructions are on [the Home Assistant developers website](https://developers.home-assistant.io/docs/add-ons/testing) but the basic steps are: 

1. Download the `Remote - Containers` Visual Studio Code extension
2. Open the repo in a dev container
3. Go to 'Run Task - Start Home Assistant'
4. Develop!
